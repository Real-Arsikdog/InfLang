package inftlang;

public class Token {
    public enum TokenType {
        // Keywords
        VAR, IF, ELSE, WHILE, FUNC, RETURN, PIN,

        // Literals
        IDENTIFIER, INT_LITERAL, FLOAT_LITERAL, STRING_LITERAL, BOOLEAN_LITERAL,

        // Operators
        PLUS, MINUS, MULTIPLY, DIVIDE, ASSIGN,
        EQ, NE, LT, LE, GT, GE,

        // Delimiters
        LPAREN, RPAREN, LBRACE, RBRACE, SEMICOLON, COMMA,

        // End of File
        EOF
    }

    public final TokenType type;
    public final String lexeme;
    public final Object literal;
    public final int line;

    public Token(TokenType type, String lexeme, Object literal, int line) {
        this.type = type;
        this.lexeme = lexeme;
        this.literal = literal;
        this.line = line;
    }

    @Override
    public String toString() {
        return "Token{" +
               "type=" + type +
               ", lexeme='" + lexeme + '\'' +
               ", literal=" + literal +
               ", line=" + line +
               '}'
        ;
    }
}


