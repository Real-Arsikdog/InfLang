package inftlang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Lexer {
    private static final Map<String, Token.TokenType> keywords;

    static {
        keywords = new HashMap<>();
        keywords.put("var", Token.TokenType.VAR);
        keywords.put("if", Token.TokenType.IF);
        keywords.put("else", Token.TokenType.ELSE);
        keywords.put("while", Token.TokenType.WHILE);
        keywords.put("func", Token.TokenType.FUNC);
        keywords.put("return", Token.TokenType.RETURN);
        keywords.put("pin", Token.TokenType.PIN);
        keywords.put("true", Token.TokenType.BOOLEAN_LITERAL);
        keywords.put("false", Token.TokenType.BOOLEAN_LITERAL);
    }

    private final String source;
    private final List<Token> tokens = new ArrayList<>();
    private int start = 0;
    private int current = 0;
    private int line = 1;

    public Lexer(String source) {
        this.source = source;
    }

    public List<Token> scanTokens() {
        while (!isAtEnd()) {
            start = current;
            scanToken();
        }

        tokens.add(new Token(Token.TokenType.EOF, "", null, line));
        return tokens;
    }

    private void scanToken() {
        char c = advance();
        switch (c) {
            case ' ':
            case '\r':
            case '\t':
                // Ignore whitespace.
                break;
            case '\n':
                line++;
                break;
            case '(':
                addToken(Token.TokenType.LPAREN);
                break;
            case ')':
                addToken(Token.TokenType.RPAREN);
                break;
            case '{':
                addToken(Token.TokenType.LBRACE);
                break;
            case '}':
                addToken(Token.TokenType.RBRACE);
                break;
            case ',':
                addToken(Token.TokenType.COMMA);
                break;
            case ';':
                addToken(Token.TokenType.SEMICOLON);
                break;
            case '+':
                addToken(Token.TokenType.PLUS);
                break;
            case '-':
                addToken(Token.TokenType.MINUS);
                break;
            case '*':
                addToken(Token.TokenType.MULTIPLY);
                break;
            case '/':
                if (match('/')) {
                    // A comment goes until the end of the line.
                    while (peek() != '\n' && !isAtEnd()) advance();
                } else if (match('*')) {
                    blockComment();
                } else {
                    addToken(Token.TokenType.DIVIDE);
                }
                break;
            case '=':
                addToken(match('=') ? Token.TokenType.EQ : Token.TokenType.ASSIGN);
                break;
            case '!':
                addToken(match('=') ? Token.TokenType.NE : null);
                break;
            case '<':
                addToken(match('=') ? Token.TokenType.LE : Token.TokenType.LT);
                break;
            case '>':
                addToken(match('=') ? Token.TokenType.GE : Token.TokenType.GT);
                break;
            case '"':
                string();
                break;
            default:
                if (isDigit(c)) {
                    number();
                } else if (isAlpha(c)) {
                    identifier();
                } else {
                    System.err.println("Unexpected character: " + c + " at line " + line);
                }
                break;
        }
    }

    private void blockComment() {
        while (!(peek() == '*' && peekNext() == '/') && !isAtEnd()) {
            if (peek() == '\n') line++;
            advance();
        }

        if (isAtEnd()) {
            System.err.println("Unterminated comment at line " + line);
            return;
        }

        // The closing */
        advance();
        advance();
    }

    private void identifier() {
        while (isAlphaNumeric(peek())) advance();

        String text = source.substring(start, current);
        Token.TokenType type = keywords.get(text);
        if (type == null) type = Token.TokenType.IDENTIFIER;
        
        if (type == Token.TokenType.BOOLEAN_LITERAL) {
            addToken(type, text.equals("true"));
        } else {
            addToken(type);
        }
    }

    private void number() {
        while (isDigit(peek())) advance();

        // Look for a fractional part.
        if (peek() == '.' && isDigit(peekNext())) {
            // Consume the "."
            advance();

            while (isDigit(peek())) advance();
            addToken(Token.TokenType.FLOAT_LITERAL, Double.parseDouble(source.substring(start, current)));
        } else {
            addToken(Token.TokenType.INT_LITERAL, Integer.parseInt(source.substring(start, current)));
        }
    }

    private void string() {
        while (peek() != '"' && !isAtEnd()) {
            if (peek() == '\n') line++;
            advance();
        }

        if (isAtEnd()) {
            System.err.println("Unterminated string at line " + line);
            return;
        }

        // The closing ".
        advance();

        // Trim the surrounding quotes.
        String value = source.substring(start + 1, current - 1);
        addToken(Token.TokenType.STRING_LITERAL, value);
    }

    private boolean match(char expected) {
        if (isAtEnd()) return false;
        if (source.charAt(current) != expected) return false;

        current++;
        return true;
    }

    private char peek() {
        if (isAtEnd()) return '\0';
        return source.charAt(current);
    }

    private char peekNext() {
        if (current + 1 >= source.length()) return '\0';
        return source.charAt(current + 1);
    }

    private boolean isAlpha(char c) {
        return (c >= 'a' && c <= 'z') ||
               (c >= 'A' && c <= 'Z') ||
                c == '_';
    }

    private boolean isAlphaNumeric(char c) {
        return isAlpha(c) || isDigit(c);
    }

    private boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    private boolean isAtEnd() {
        return current >= source.length();
    }

    private char advance() {
        return source.charAt(current++);
    }

    private void addToken(Token.TokenType type) {
        addToken(type, null);
    }

    private void addToken(Token.TokenType type, Object literal) {
        String text = source.substring(start, current);
        tokens.add(new Token(type, text, literal, line));
    }
}

