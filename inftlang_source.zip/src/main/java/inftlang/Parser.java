package inftlang;

import java.util.ArrayList;
import java.util.List;

public class Parser {
    private static class ParseError extends RuntimeException {}

    private final List<Token> tokens;
    private int current = 0;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
    }

    public List<Stmt> parse() {
        List<Stmt> statements = new ArrayList<>();
        while (!isAtEnd()) {
            statements.add(declaration());
        }

        return statements;
    }

    private Stmt declaration() {
        try {
            if (match(Token.TokenType.FUNC)) return function("function");
            if (match(Token.TokenType.VAR)) return varDeclaration();

            return statement();
        } catch (ParseError error) {
            synchronize();
            return null;
        }
    }

    private Stmt function(String kind) {
        Token name = consume(Token.TokenType.IDENTIFIER, "Expect " + kind + " name.");

        consume(Token.TokenType.LPAREN, "Expect '(' after " + kind + " name.");
        List<Token> parameters = new ArrayList<>();
        if (!check(Token.TokenType.RPAREN)) {
            do {
                parameters.add(consume(Token.TokenType.IDENTIFIER, "Expect parameter name."));
            } while (match(Token.TokenType.COMMA));
        }
        consume(Token.TokenType.RPAREN, "Expect ')' after parameters.");

        consume(Token.TokenType.LBRACE, "Expect '{' before " + kind + " body.");
        List<Stmt> body = block();
        return new Stmt.Function(name, parameters, body);
    }

    private Stmt varDeclaration() {
        Token name = consume(Token.TokenType.IDENTIFIER, "Expect variable name.");

        Expr initializer = null;
        if (match(Token.TokenType.ASSIGN)) {
            initializer = expression();
        }

        consume(Token.TokenType.SEMICOLON, "Expect ';' after variable declaration.");
        return new Stmt.Var(name, initializer);
    }

    private Stmt statement() {
        if (match(Token.TokenType.IF)) return ifStatement();
        if (match(Token.TokenType.PIN)) return pinStatement();
        if (match(Token.TokenType.RETURN)) return returnStatement();
        if (match(Token.TokenType.WHILE)) return whileStatement();
        if (match(Token.TokenType.LBRACE)) return new Stmt.Block(block());

        return expressionStatement();
    }

    private Stmt ifStatement() {
        consume(Token.TokenType.LPAREN, "Expect '(' after 'if'.");
        Expr condition = expression();
        consume(Token.TokenType.RPAREN, "Expect ')' after if condition.");

        Stmt thenBranch = statement();
        Stmt elseBranch = null;
        if (match(Token.TokenType.ELSE)) {
            elseBranch = statement();
        }

        return new Stmt.If(condition, thenBranch, elseBranch);
    }

    private Stmt pinStatement() {
        Expr value = expression();
        consume(Token.TokenType.SEMICOLON, "Expect ';' after value.");
        return new Stmt.Pin(value);
    }

    private Stmt returnStatement() {
        Token keyword = previous();
        Expr value = null;
        if (!check(Token.TokenType.SEMICOLON)) {
            value = expression();
        }

        consume(Token.TokenType.SEMICOLON, "Expect ';' after return value.");
        return new Stmt.Return(keyword, value);
    }

    private Stmt whileStatement() {
        consume(Token.TokenType.LPAREN, "Expect '(' after 'while'.");
        Expr condition = expression();
        consume(Token.TokenType.RPAREN, "Expect ')' after condition.");
        Stmt body = statement();

        return new Stmt.While(condition, body);
    }

    private List<Stmt> block() {
        List<Stmt> statements = new ArrayList<>();

        while (!check(Token.TokenType.RBRACE) && !isAtEnd()) {
            statements.add(declaration());
        }

        consume(Token.TokenType.RBRACE, "Expect '}' after block.");
        return statements;
    }

    private Stmt expressionStatement() {
        Expr expr = expression();
        consume(Token.TokenType.SEMICOLON, "Expect ';' after expression.");
        return new Stmt.Expression(expr);
    }

    private Expr expression() {
        return assignment();
    }

    private Expr assignment() {
        Expr expr = or();

        if (match(Token.TokenType.ASSIGN)) {
            Token equals = previous();
            Expr value = assignment();

            if (expr instanceof Expr.Variable) {
                Token name = ((Expr.Variable)expr).name;
                return new Expr.Assign(name, value);
            }

            error(equals, "Invalid assignment target.");
        }

        return expr;
    }

    private Expr or() {
        Expr expr = and();

        while (match(Token.TokenType.EQ)) {
            Token operator = previous();
            Expr right = and();
            expr = new Expr.Binary(expr, operator, right);
        }

        return expr;
    }

    private Expr and() {
        Expr expr = equality();

        while (match(Token.TokenType.NE)) {
            Token operator = previous();
            Expr right = equality();
            expr = new Expr.Binary(expr, operator, right);
        }

        return expr;
    }

    private Expr equality() {
        Expr expr = comparison();

        while (match(Token.TokenType.NE, Token.TokenType.EQ)) {
            Token operator = previous();
            Expr right = comparison();
            expr = new Expr.Binary(expr, operator, right);
        }

        return expr;
    }

    private Expr comparison() {
        Expr expr = term();

        while (match(Token.TokenType.GT, Token.TokenType.GE, Token.TokenType.LT, Token.TokenType.LE)) {
            Token operator = previous();
            Expr right = term();
            expr = new Expr.Binary(expr, operator, right);
        }

        return expr;
    }

    private Expr term() {
        Expr expr = factor();

        while (match(Token.TokenType.MINUS, Token.TokenType.PLUS)) {
            Token operator = previous();
            Expr right = factor();
            expr = new Expr.Binary(expr, operator, right);
        }

        return expr;
    }

    private Expr factor() {
        Expr expr = unary();

        while (match(Token.TokenType.DIVIDE, Token.TokenType.MULTIPLY)) {
            Token operator = previous();
            Expr right = unary();
            expr = new Expr.Binary(expr, operator, right);
        }

        return expr;
    }

    private Expr unary() {
        if (match(Token.TokenType.MINUS)) {
            Token operator = previous();
            Expr right = unary();
            return new Expr.Unary(operator, right);
        }

        return call();
    }

    private Expr call() {
        Expr expr = primary();

        while (true) {
            if (match(Token.TokenType.LPAREN)) {
                expr = finishCall(expr);
            } else {
                break;
            }
        }

        return expr;
    }

    private Expr finishCall(Expr callee) {
        List<Expr> arguments = new ArrayList<>();
        if (!check(Token.TokenType.RPAREN)) {
            do {
                arguments.add(expression());
            } while (match(Token.TokenType.COMMA));
        }

        Token paren = consume(Token.TokenType.RPAREN, "Expect ')' after arguments.");
        return new Expr.Call(callee, paren, arguments);
    }

    private Expr primary() {
        if (match(Token.TokenType.BOOLEAN_LITERAL, Token.TokenType.INT_LITERAL, Token.TokenType.FLOAT_LITERAL, Token.TokenType.STRING_LITERAL)) {
            return new Expr.Literal(previous().literal);
        }

        if (match(Token.TokenType.IDENTIFIER)) {
            return new Expr.Variable(previous());
        }

        if (match(Token.TokenType.LPAREN)) {
            Expr expr = expression();
            consume(Token.TokenType.RPAREN, "Expect ')' after expression.");
            return new Expr.Grouping(expr);
        }

        throw error(peek(), "Expect expression.");
    }

    private boolean match(Token.TokenType... types) {
        for (Token.TokenType type : types) {
            if (check(type)) {
                advance();
                return true;
            }
        }

        return false;
    }

    private Token consume(Token.TokenType type, String message) {
        if (check(type)) return advance();

        throw error(peek(), message);
    }

    private boolean check(Token.TokenType type) {
        if (isAtEnd()) return false;
        return peek().type == type;
    }

    private Token advance() {
        if (!isAtEnd()) current++;
        return previous();
    }

    private boolean isAtEnd() {
        return peek().type == Token.TokenType.EOF;
    }

    private Token peek() {
        return tokens.get(current);
    }

    private Token previous() {
        return tokens.get(current - 1);
    }

    private ParseError error(Token token, String message) {
        System.err.println("Error at line " + token.line + ": " + message);
        return new ParseError();
    }

    private void synchronize() {
        advance();

        while (!isAtEnd()) {
            if (previous().type == Token.TokenType.SEMICOLON) return;

            switch (peek().type) {
                case VAR:
                case FUNC:
                case IF:
                case WHILE:
                case PIN:
                case RETURN:
                    return;
            }

            advance();
        }
    }
}

