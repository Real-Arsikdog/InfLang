
# InfLang Language Specification

## 1. Data Types
InfLang will support the following basic data types:
- `int`: for integer numbers (e.g., 10, -5)
- `float`: for floating-point numbers (e.g., 3.14, -0.5)
- `string`: for sequences of characters (e.g., "hello", "InfLang")
- `boolean`: for true/false values (e.g., true, false)

## 2. Variable Declaration and Assignment
Variables are declared using the `var` keyword, followed by the variable name and an optional assignment using the `=` operator.

### Syntax:
`var variable_name [= initial_value];`

### Examples:
`var x = 10;`
`var name = "InfLang";`
`var is_active = true;`
`var pi = 3.14;`
`var counter; // Declaration without initial assignment`



## 3. Control Flow Statements

### 3.1. Conditional Statements (if/else)
InfLang supports `if` and `else` statements for conditional execution. The condition must be enclosed in parentheses, and the code block in curly braces.

### Syntax:
```inftlang
if (condition) {
    // code to execute if condition is true
} else {
    // code to execute if condition is false
}
```

### Examples:
```inftlang
var num = 10;
if (num > 5) {
    pin "Number is greater than 5";
} else {
    pin "Number is 5 or less";
}
```

### 3.2. Loop Statements (while)
InfLang supports `while` loops for repetitive execution. The condition must be enclosed in parentheses, and the code block in curly braces.

### Syntax:
```inftlang
while (condition) {
    // code to execute repeatedly while condition is true
}
```

### Examples:
```inftlang
var count = 0;
while (count < 5) {
    pin "Count: " + count;
    count = count + 1;
}
```



## 4. Function Declaration and Calling

InfLang supports functions for modularizing code. Functions are declared using the `func` keyword, followed by the function name, parameters in parentheses, and the code block in curly braces.

### Syntax:
```inftlang
func function_name(parameter1, parameter2) {
    // function body
    return value; // Optional return statement
}
```

### Examples:
```inftlang
func add(a, b) {
    return a + b;
}

var result = add(5, 3);
pin "Result of add: " + result;
```

## 5. Output Statement (pin)

InfLang uses the `pin` keyword for outputting values to the console, similar to `print` in Python.

### Syntax:
`pin expression;`

### Examples:
`pin "Hello, InfLang!";`
`var message = "This is a message";
pin message;`
`pin 123 + 456;`

## 6. Comments

InfLang supports single-line and multi-line comments.

### Syntax:
- Single-line comment: `// This is a single-line comment`
- Multi-line comment: 
```inftlang
/*
This is a
multi-line comment
*/
```


